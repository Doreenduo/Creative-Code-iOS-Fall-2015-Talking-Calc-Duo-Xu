//
//  ViewController.swift
//  Speak Calculator
//
//  Created by XuDuo on 15/10/18.
//  Copyright © 2015年 XuDuo. All rights reserved.
//

import UIKit
import AVFoundation


class ViewController: UIViewController,UIPickerViewDataSource, UIPickerViewDelegate {
    
    //  ViewController Class-Wide Variables
    let mySpeechSynth = AVSpeechSynthesizer()

    
    // calc related
    var currentString = ""
    var total:Int = 0
    var mode:Int = 0
    var valueString: String! = ""
    var languageString: String! = ""
    var lastButtonWasMode:Bool = false
    var totalEquals: Bool = false
    var speechVolume:Float = 1.0
    
    
    var currentLang = ("en-US", "English","United States","American English ","🇺🇸")
    
    // from :http://www.geonames.de/languages.html , http://www.omniglot.com/language/names.htm , http://wpcentral.io/internationalization/
    // current lang array has known typos, to fix in future.
    var langCodeAll38 = [
        ("en-US",  "English", "United States", "American English","🇺🇸"),
        ("ar-SA","Arabic","Saudi Arabia","العربية","🇸🇦"),
        ("cs-CZ", "Czech", "Czech Republic","český","🇨🇿"),
        ("da-DK", "Danish","Denmark","Dansk","🇩🇰"),
        ("de-DE",       "German", "Germany", "Deutsche","🇩🇪"),
        ("el-GR",      "Modern Greek",        "Greece","ελληνική","🇬🇷"),
        ("en-AU",     "English",     "Australia","Aussie","🇦🇺"),
        ("en-GB",     "English",     "United Kingdom", "Queen's English","🇬🇧"),
        ("en-IE",      "English",     "Ireland", "Gaeilge","🇮🇪"),
        ("en-ZA",       "English",     "South Africa", "South African English","🇿🇦"),
        ("es-ES",       "Spanish",     "Spain", "Español","🇪🇸"),
        ("es-MX",       "Spanish",     "Mexico", "Español de México","🇲🇽"),
        ("fi-FI",       "Finnish",     "Finland","Suomi","🇫🇮"),
        ("fr-CA",       "French",      "Canada","Français du Canada","🇨🇦" ),
        ("fr-FR",       "French",      "France", "Français","🇫🇷"),
        ("he-IL",       "Hebrew",      "Israel","עברית","🇮🇱"),
        ("hi-IN",       "Hindi",       "India", "हिन्दी","🇮🇳"),
        ("hu-HU",       "Hungarian",    "Hungary", "Magyar","🇭🇺"),
        ("id-ID",       "Indonesian",    "Indonesia","Bahasa Indonesia","🇮🇩"),
        ("it-IT",       "Italian",     "Italy", "Italiano","🇮🇹"),
        ("ja-JP",       "Japanese",     "Japan", "日本語","🇯🇵"),
        ("ko-KR",       "Korean",      "Republic of Korea", "한국어","🇰🇷"),
        ("nl-BE",       "Dutch",       "Belgium","Nederlandse","🇧🇪"),
        ("nl-NL",       "Dutch",       "Netherlands", "Nederlands","🇳🇱"),
        ("no-NO",       "Norwegian",    "Norway", "Norsk","🇳🇴"),
        ("pl-PL",       "Polish",      "Poland", "Polski","🇵🇱"),
        ("pt-BR",       "Portuguese",      "Brazil","Portuguese","🇧🇷"),
        ("pt-PT",       "Portuguese",      "Portugal","Portuguese","🇵🇹"),
        ("ro-RO",       "Romanian",        "Romania","Română","🇷🇴"),
        ("ru-RU",       "Russian",     "Russian Federation","русский","🇷🇺"),
        ("sk-SK",       "Slovak",      "Slovakia", "Slovenčina","🇸🇰"),
        ("sv-SE",       "Swedish",     "Sweden","Svenska","🇸🇪"),
        ("th-TH",       "Thai",        "Thailand","ภาษาไทย","🇹🇭"),
        ("tr-TR",       "Turkish",     "Turkey","Türkçe","🇹🇷"),
        ("zh-CN",       "Chinese",     "China","漢語/汉语","🇨🇳"),
        ("zh-HK",       "Chinese",   "Hong Kong","漢語/汉语","🇭🇰"),
        ("zh-TW",       "Chinese",     "Taiwan","漢語/汉语","🇹🇼")
    ]
    
    
    
    
    //UI Elements
    
    @IBOutlet weak var labelNumberDisplay: UILabel!
    @IBAction func numberButtonPressed(sender: UIButton) {
        
        // Save Data
        let myString =  sender.titleLabel?.text
        currentString = myString!
        speakThisString(currentString)
   //     updateLabelDisplayingNumbers()
    }
    
    
    @IBOutlet weak var soundLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelNumberDisplay.text = "💗👫👬👭👯💗"
        
        // Basic Speaking Code.
        let myUtterance = AVSpeechUtterance(string: "Hello I am a speak Calculator.")
        myUtterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        mySpeechSynth.speakUtterance(myUtterance)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // basic calc funtions
    
    @IBAction func tappedNumber(sender: UIButton) {
        
        if(totalEquals){
            totalEquals = false
            valueString = ""
        }
        
        
        let str:String! = sender.titleLabel!.text
        let num:Int! = Int(str!)
        //make "0 just have one for the first time click
        if (num == 0 && total == 0)
        {
            return
        }
        
        if(lastButtonWasMode){
            lastButtonWasMode = false
            valueString = ""
        }
        
 
        valueString = valueString.stringByAppendingString(str)
        let formatter:NSNumberFormatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        let n:NSNumber = formatter.numberFromString(valueString)!
        labelNumberDisplay.text = formatter.stringFromNumber(n)
        if (total == 0){
            total = Int(valueString)!
  
    }
         speakThisString(valueString)
    
    }
    
    //all buttons
    @IBOutlet weak var plus: UIButton!
    @IBOutlet weak var Minus: UIButton!
    @IBOutlet weak var Multiply: UIButton!
    @IBOutlet weak var Equal: UIButton!
    @IBOutlet weak var Zero: UIButton!
    @IBOutlet weak var Clearn: UIButton!
    @IBOutlet weak var One: UIButton!
    @IBOutlet weak var Two: UIButton!
    @IBOutlet weak var Three: UIButton!
    @IBOutlet weak var Four: UIButton!
    @IBOutlet weak var Five: UIButton!
    @IBOutlet weak var Six: UIButton!
    @IBOutlet weak var Seven: UIButton!
    @IBOutlet weak var Eight: UIButton!
    @IBOutlet weak var Night: UIButton!

    
    
    // Day night mode change
    @IBOutlet weak var visualControl: UISegmentedControl!
    @IBAction func myColor(sender: AnyObject) {
        if visualControl.selectedSegmentIndex == 0{
            speakThisString("Day Mode")
            plus.backgroundColor = UIColor(red: 0.99, green: 0.59, blue: 0.31, alpha: 1)
            Minus.backgroundColor = UIColor(red: 0.99, green: 0.59, blue: 0.31, alpha: 1)
            Multiply.backgroundColor = UIColor(red: 0.99, green: 0.59, blue: 0.31, alpha: 1)
            Equal.backgroundColor = UIColor(red: 0.99, green: 0.59, blue: 0.31, alpha: 1)
            Clearn.backgroundColor = UIColor(red: 0.80, green: 0.80, blue: 0.80, alpha: 1)
            Zero.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            One.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Two.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Three.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Four.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Five.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Six.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Seven.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Eight.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            Night.backgroundColor = UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1)
            view.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)
            labelNumberDisplay.textColor = UIColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1)
            soundLabel.textColor = UIColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1)
        }
        
        if visualControl.selectedSegmentIndex == 1{
            speakThisString("Night Mode")
            plus.backgroundColor = UIColor(red: 0.35, green: 0.63, blue: 0.63, alpha: 1)
            Minus.backgroundColor = UIColor(red: 0.35, green: 0.63, blue: 0.63, alpha: 1)
            Multiply.backgroundColor = UIColor(red: 0.35, green: 0.63, blue: 0.63, alpha: 1)
            Equal.backgroundColor = UIColor(red: 0.35, green: 0.63, blue: 0.63, alpha: 1)
            Clearn.backgroundColor = UIColor(red: 0.55, green: 0.63, blue: 0.63, alpha: 1)
            Zero.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            One.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Two.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Three.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Four.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Five.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Six.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Seven.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Eight.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            Night.backgroundColor = UIColor(red: 0.79, green: 0.79, blue: 0.79, alpha: 1)
            view.backgroundColor = UIColor(red: 0.39, green: 0.39, blue: 0.39, alpha: 1)
            labelNumberDisplay.textColor = UIColor(red: 0.99, green: 0.99, blue: 0.99, alpha: 1)
            soundLabel.textColor = UIColor(red: 0.99, green: 0.99, blue: 0.99, alpha: 1)
        }
   
        
    }
    
    
    
    
    
    // Basic calc code
    @IBAction func tappedPlus(sender: UIButton) {
        self.setmode(1)
       speakThisString("Plus")
    }
    
    
    @IBAction func tappedMinus(sender: UIButton) {
        self.setmode(-1)
      speakThisString("Minus")

    }
    
    
    @IBAction func tappedMultiply(sender: UIButton) {
        self.setmode(2)
      speakThisString("Times")

    }
   
    
    @IBAction func tappedEquals(sender: UIButton) {
        if(mode == 0){
            return
        }
        let iNum:Int = Int(valueString)!
        
        
        if(mode == 1){
            total += iNum
        }
        
        if(mode == -1){
            total -= iNum
        }
        
        if(mode == 2){
            total *= iNum
        }
        
        valueString = "\(total)"
        
        speakThisString("equals")
        
        speakThisString(valueString)
        
        let formatter:NSNumberFormatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        let n:NSNumber = formatter.numberFromString(valueString)!
        labelNumberDisplay.text = formatter.stringFromNumber(n)
        mode = 0
        totalEquals = true
    }
    
    
    @IBAction func tappedClear(sender: UIButton) {
        total = 0
        mode = 0
        valueString = ""
        labelNumberDisplay.text = "0"
        lastButtonWasMode = false
        speakThisString("Clear")
    }
    
    func setmode(m:Int)
    {
        if(total == 0){
            return
        }
        mode = m
        lastButtonWasMode = true
        total = Int(valueString)!
    }


    //MARK - Switches
    
    
    @IBAction func soundSwitch(sender: UISwitch) {
        if sender.on {
            speechVolume = 1.0
            soundLabel.text = "SOUND ON"
            
        } else {
            speechVolume = 0.0
            soundLabel.text = "SOUND OFF"
        }
    }

    
    
    //MARK - UIPickerView Methods
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return langCodeAll38.count
    }
    
    
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        let myString = "\(langCodeAll38[row].4) \(langCodeAll38[row].3)"
        
        return myString
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        currentLang = langCodeAll38[row]
        speakThisString(currentLang.3)
    }
    
    
    //MARK - Calc Functions
    
    func updateLabelDisplayingNumbers(){
        labelNumberDisplay.text = currentString
    }
    
    
    //MARK - Speaking Machine
    
    func speakThisString(passedString: String){
        
        mySpeechSynth.stopSpeakingAtBoundary(AVSpeechBoundary.Immediate)
    let myUtterance = AVSpeechUtterance(string: passedString)
        myUtterance.voice = AVSpeechSynthesisVoice(language: currentLang.0)
        myUtterance.volume = speechVolume
        mySpeechSynth.speakUtterance(myUtterance)
        
    }
        
}